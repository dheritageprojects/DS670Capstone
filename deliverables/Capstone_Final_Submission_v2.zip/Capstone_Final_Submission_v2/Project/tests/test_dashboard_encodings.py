"""Verify physical numeric chart inputs, cohort arithmetic and filter preservation."""
import copy
import sqlite3
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'dashboard'))
from build_sensitivity import build_page
from repair_visualizations import repair_definition, METHODS, METRICS

class DashboardEncodingTests(unittest.TestCase):
    def definition(self):
        return {'datasets':[{'name':'sensitivity_live','query':'SELECT * FROM raw_sensitivity'},{'name':'county_panel','query':'SELECT * FROM raw_county'},{'name':'quality','query':'SELECT unchanged'}],'pages':[build_page()]}

    def test_numeric_fields_and_filter_preservation(self):
        original=self.definition();frozen=copy.deepcopy(original);fixed=repair_definition(original)
        self.assertEqual(original,frozen)
        self.assertEqual(fixed['datasets'][2],original['datasets'][2])
        self.assertIn('AS fixed_measure',fixed['datasets'][0]['query'])
        self.assertIn('AS complete_overdose_count',fixed['datasets'][1]['query'])
        self.assertEqual(repair_definition(fixed),fixed)
        for before,after in zip(original['pages'][0]['layout'],fixed['pages'][0]['layout']):
            if before['widget'].get('spec',{}).get('widgetType')!='line':
                self.assertEqual(before,after);continue
            w=after['widget'];q=w['queries'][0]['query'];agg,col=METRICS[w['name']]
            self.assertEqual(q['fields'][-1]['expression'],f'{agg}(`{col}`)')
            self.assertEqual(w['spec']['encodings']['y']['fieldName'],q['fields'][-1]['name'])
            self.assertEqual(w['spec']['encodings']['color']['fieldName'],'method')
            self.assertEqual(before['widget']['spec']['frame'],w['spec']['frame'])

    def test_physical_numeric_arithmetic_matches_independent_groups(self):
        records=[]
        for year in [2020,2024]:
            for county in [0,1,2]:
                for i,(method,_) in enumerate(METHODS):
                    value=None if county==2 and i>0 else 10+county*5+i+(year-2020)
                    records.append((year,method,value,10+county*5,value is not None,county!=2,county==0))
        con=sqlite3.connect(':memory:')
        con.execute('CREATE TABLE raw_sensitivity(year INT,method TEXT,overdose_measure REAL,december_count REAL,complete_case INT,common_within_year INT,common_all_years INT)')
        con.executemany('INSERT INTO raw_sensitivity VALUES (?,?,?,?,?,?,?)',records)
        fixed=repair_definition(self.definition());sql=fixed['datasets'][0]['query']
        self.assertEqual(con.execute('SELECT COUNT(*) FROM ('+sql+')').fetchone()[0],len(records))
        for item in fixed['pages'][0]['layout']:
            w=item['widget'];name=w['name']
            if name not in METRICS:continue
            projection=','.join(f['expression'] for f in w['queries'][0]['query']['fields'])
            for row in con.execute('SELECT '+projection+' FROM ('+sql+') GROUP BY year,method'):
                group=[r for r in records if r[0]==row[0] and r[1]==row[1]]
                if name=='sensitivity_coverage':expected=sum(bool(r[4]) for r in group)
                elif name=='sensitivity_missing':expected=sum(r[2] is None for r in group)
                else:
                    flag={'sensitivity_available_means':4,'sensitivity_shared_means':5,'sensitivity_fixed_means':6,'sensitivity_differences':4}[name]
                    values=[r[2]-r[3] if name=='sensitivity_differences' else r[2] for r in group if r[flag] and r[2] is not None and (name!='sensitivity_differences' or r[3] is not None)]
                    expected=sum(values)/len(values) if values else None
                if expected is None:self.assertIsNone(row[2])
                else:self.assertAlmostEqual(row[2],expected)
        con.close()

    def test_scatter_retains_null_incomplete_pairs(self):
        original=self.definition();original['pages'][0]['layout'].append({'widget':{'name':'association','queries':[{'query':{}}],'spec':{}}})
        fixed=repair_definition(original)
        con=sqlite3.connect(':memory:')
        con.execute('CREATE TABLE raw_county(complete_case INT,dispensing_rate REAL,overdose_count REAL)')
        con.executemany('INSERT INTO raw_county VALUES (?,?,?)',[(1,13,112),(0,20,None)])
        rows=list(con.execute('SELECT complete_dispensing_rate,complete_overdose_count FROM ('+fixed['datasets'][1]['query']+')'))
        self.assertEqual(rows,[(13,112),(None,None)])
        widget=fixed['pages'][0]['layout'][-1]['widget']
        self.assertTrue(widget['queries'][0]['query']['disaggregated'])
        self.assertEqual(widget['spec']['encodings']['y']['fieldName'],'complete_overdose_count')
        con.close()

if __name__=='__main__':unittest.main()
