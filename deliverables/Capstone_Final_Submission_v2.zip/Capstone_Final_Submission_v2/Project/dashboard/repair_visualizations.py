"""Expose numeric chart inputs in the datasets and bind simple aggregates."""
import copy
import json
from pathlib import Path

METHODS=[('december','December'),('december_trailing_mean_3','Trailing 3-month mean'),('quarter_end_mean_4','Quarter-end mean'),('monthly_mean_12','All-month mean')]
METRICS={
    'sensitivity_coverage':('SUM','complete_case_n'),
    'sensitivity_available_means':('AVG','available_measure'),
    'sensitivity_shared_means':('AVG','shared_measure'),
    'sensitivity_fixed_means':('AVG','fixed_measure'),
    'sensitivity_differences':('AVG','paired_difference'),
    'sensitivity_missing':('SUM','missing_measure_n'),
}

def repair_definition(current):
    # Work on a copy; source tables, global filters and geographic keys are retained.
    result=copy.deepcopy(current)
    for dataset in result.get('datasets',[]):
        name=dataset['name']
        if name not in ('county_panel','sensitivity_live'):
            continue
        sql=dataset.get('query') or ''.join(dataset.get('queryLines',[]))
        if not sql or '-- capstone_numeric_chart_inputs' in sql:
            continue
        if name=='county_panel':
            columns='''CASE WHEN complete_case THEN CAST(dispensing_rate AS DOUBLE) END AS complete_dispensing_rate,
CASE WHEN complete_case THEN CAST(overdose_count AS DOUBLE) END AS complete_overdose_count'''
        else:
            columns='''CAST(complete_case AS INT) AS complete_case_n,
CASE WHEN overdose_measure IS NULL THEN 1 ELSE 0 END AS missing_measure_n,
CASE WHEN complete_case THEN CAST(overdose_measure AS DOUBLE) END AS available_measure,
CASE WHEN common_within_year THEN CAST(overdose_measure AS DOUBLE) END AS shared_measure,
CASE WHEN common_all_years THEN CAST(overdose_measure AS DOUBLE) END AS fixed_measure,
CASE WHEN complete_case AND december_count IS NOT NULL THEN CAST(overdose_measure - december_count AS DOUBLE) END AS paired_difference'''
        wrapped='-- capstone_numeric_chart_inputs\nWITH chart_source AS (\n'+sql.strip().rstrip(';')+'\n)\nSELECT *,\n'+columns+'\nFROM chart_source'
        if 'queryLines' in dataset:
            dataset['queryLines']=wrapped.splitlines(keepends=True)
        else:
            dataset['query']=wrapped
    # Use only direct numeric inputs and simple aggregates in widget projections.
    for page in result['pages']:
        for item in page['layout']:
            widget=item['widget']; name=widget['name']; spec=widget.get('spec',{})
            if name=='association':
                query=widget['queries'][0]['query']
                query['fields']=[{'name':c,'expression':f'`{c}`'} for c in ['county_fips','year','state','complete_dispensing_rate','complete_overdose_count']]
                query['disaggregated']=True
                spec['encodings']={
                    'x':{'fieldName':'complete_dispensing_rate','displayName':'Dispensing rate per 100 persons','scale':{'type':'quantitative'}},
                    'y':{'fieldName':'complete_overdose_count','displayName':'Reported overdose count','scale':{'type':'quantitative'}},
                }
            elif name in METRICS and spec.get('widgetType')=='line':
                aggregate,column=METRICS[name]; alias=f'{aggregate.lower()}({column})'
                widget['queries'][0]['query']['fields']=[
                    {'name':'year','expression':'`year`'},
                    {'name':'method','expression':'`method`'},
                    {'name':alias,'expression':f'{aggregate}(`{column}`)'},
                ]
                spec['encodings']={
                    'x':{'fieldName':'year','displayName':'Year','scale':{'type':'categorical'}},
                    'y':{'fieldName':alias,'displayName':{'complete_case_n':'Complete county-years','missing_measure_n':'Missing county-years','paired_difference':'Mean difference from December'}.get(column,'Mean reported snapshot count'),'scale':{'type':'quantitative'}},
                    'color':{'fieldName':'method','displayName':'Time summary','scale':{'type':'categorical'}},
                }
    return result

if __name__=='__main__':
    import sys
    current=json.loads(Path(sys.argv[1]).read_text())
    Path(sys.argv[2]).write_text(json.dumps(repair_definition(current),indent=2)+'\n')
