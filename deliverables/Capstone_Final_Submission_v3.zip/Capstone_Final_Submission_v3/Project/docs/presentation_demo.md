# Presentation demonstration and recording guide

The revised 16-slide presentation and matching script target **14 minutes 25 seconds**, including **3 minutes 30 seconds** for a real dashboard walkthrough on slide 15. This is a rehearsal plan, not a measured video duration. Record and check the actual total: the assignment requires 10–15 minutes.

## Dashboard and preparation

[Open the existing Databricks dashboard draft](https://dbc-dc957048-d7f2.cloud.databricks.com/sql/dashboardsv3/01f1df0509d010f987459df183dcdd91?o=7474646615740609).

Sign in before recording. Open both pages, let their queries finish, and rehearse the filter changes. Use an enlarged browser view so chart labels and the detail table are readable in a 1080p recording. Record the presentation and browser window with your own narration; keep notifications and sign-in screens out of the footage.

The dashboard API was read successfully on November 15, 2026. It confirms both page definitions and all three filters on each page. This is not a new browser rendering or filter acceptance test. Earlier filter acceptance remains user-reported. No browser capture tool was available in the authoring session. The user subsequently supplied genuine overview and county-example captures; these are now incorporated. A video has not been produced. Refreshed original captures now show all six sensitivity plots rendering with numeric axes and distinct series. A separate inline relationship capture shows numeric axes and points. Before recording a complete point-cloud view, use Render more data when offered or state that the view is a preview.

## Slide 15 live walkthrough

These times are relative to the beginning of the demonstration. The demonstration begins at the script target time **08:35** and ends at **12:05**. Return to slide 16 for the conclusion, ending around **14:25**. Narrate the script while performing the actions rather than reading it first and then repeating the demonstration silently.

| Demo time | Action | Point to explain |
|---|---|---|
| 00:00–00:35 | Open **County trends and coverage**. Clear Year, State, and County FIPS selections. Show the dispensing trend, overdose subtotal and reporting coverage. | The mortality subtotal excludes missing counties and is not a population-adjusted rate. Read coverage alongside outcomes. |
| 00:35–01:10 | Select Year **2024**, then State **New Jersey**. Show the state comparisons and scroll to county details. | One observation is one county in one year. Comparisons depend on county populations and reporting. |
| 01:10–01:40 | Select County FIPS **34017**, Hudson County. Show its county-year row and relationship plot. | The filters change the view; a single point does not establish a relationship or causal effect. |
| 01:40–02:00 | Clear all three selections. Briefly show **Pipeline validation — not affected by dashboard filters**. | This validation table intentionally describes the whole pipeline rather than the selected county. If showing the unfiltered scatter at this stage, click Render more data when available, or disclose the preview. |
| 02:00–02:45 | Switch to **Annualization sensitivity** and clear all three selections on this page too. Show available, shared-within-year and fixed-cohort mean charts. | The four methods use different time definitions. Available cases may contain different counties; the unfiltered fixed view uses 865 counties complete for every method and year. |
| 02:45–03:15 | Show **Complete county-years by method**, **Missing overdose measures by method**, and the sensitivity detail table. | Strict smoothing preserves missing values; it does not impute suppressed counts. The table retains method and cohort flags. |
| 03:15–03:30 | Confirm filters are cleared, then return to slide 16. | Conclude with the temporal sensitivity finding and remaining limitations. |

If a query is slow, pause naturally; do not claim a view has updated until it has rendered. Rehearse to keep the full recording within the required limit. Do not replace missing/suppressed cells with zero to make the demo appear complete.

## Source-based sanity check for the example county

The frozen files contain Hudson County, New Jersey, FIPS 34017, in 2024. Its dispensing rate is **13 prescriptions per 100 persons**, and its reported December overdose count is **112**. All 12 monthly snapshots are reported. Derived values are:

- October–December snapshot mean: **118.3333**.
- Four quarter-end snapshot mean: **146.75**.
- All-month snapshot mean: **150.6667**.

These values were checked from the frozen CSV snapshots, not observed in a new UI test. Dashboard rounding may differ. Do not use this one county to imply a national trend or a causal association.

## Genuine screenshot capture

Capture the real Databricks browser window after queries finish. Prefer these views:

1. **County trends and coverage** with all filters cleared, showing the page title, filters, trends and reporting coverage.
2. The same page filtered to 2024, New Jersey, County FIPS 34017, showing county details.
3. **Annualization sensitivity** with all filters cleared, showing the fixed-cohort comparison and its legend.
4. Sensitivity coverage/missingness, including method labels.

Use PNG files named `dashboard_overview.png`, `dashboard_county_example.png`, `dashboard_sensitivity.png`, and `dashboard_missingness.png`. Retain a caption stating the page, selections, and capture date. Keep the original captures as supporting materials. The updated presentation contains genuine overview captures and a Hudson County row; the report includes a dashboard evidence appendix. The refreshed sensitivity controls, coverage/means, shared/fixed cohorts, paired differences/missingness and detail captures are now incorporated in the report and supporting materials. The presentation uses the actual shared/fixed-cohort capture. The original relationship image was subsequently supplied in the latest ZIP and is now embedded in the report and presentation. The screenshot does not establish its hidden filter selections or full rendered point count.

## Recording and submission

Use PowerPoint recording with screen capture, OBS, or another recorder that captures your slide show, browser window and microphone. A slide-only export will not show the interactive dashboard unless the demonstration footage is inserted.

Export MP4 or upload the video to an allowed sharing service. Play it from beginning to end and check duration, audio, readable labels and both dashboard pages. For a video link, test that a viewer outside your account can open it with the permissions you intend. Your instructor does not need Databricks access to evaluate a complete recorded demonstration.

Submit the report, final presentation, source/dataset/documentation package, and the MP4 or video link. The speaking script and pipeline diagram are supporting materials. No video recording or hosted upload is included in the generated package.
