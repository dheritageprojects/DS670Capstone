# Requirements audit

Review date: November 15, 2026. Status is based on repository artifacts, recorded Databricks query results, CI runs, and the user's dashboard review. This is an evidence audit, not a declaration that the capstone is ready for submission.

Legend: **Done** = implemented with stated evidence; **Partial** = implemented but limited or awaiting an execution step; **Open** = required evidence or action absent.

## Original technical requirements

| Requirement | Status | Evidence and remaining work |
|---|---|---|
| PySpark as primary pipeline | Done | `01_pipeline.py` executed in CI and Databricks; primary Delta tables queried successfully. |
| Modular, documented notebooks | Partial | Setup, primary processing, and sensitivity are separated into three documented notebooks. Primary parsing/validation/join logic remains within one notebook; no independently packaged transformation library. Research SQL and reference calculations are separate modules. |
| Description before each code section | Done | Notebook sections and analysis stages have explanatory comments/Markdown. No formal style linter enforces this. |
| Five-character FIPS strings | Done | Normalization and invalid-key checks implemented. Geography differences and alias duplicates documented. |
| Suppressed overdose values remain missing | Done | Source blank/suppression handling, strict-window rules, and independent reference tests; literal reported zeros preserved. |
| Investigate December, quarterly, rolling approaches | Done | All methods implemented and compared. All five sensitivity outputs are Delta in Databricks; source/window parity and independently calculated summary/paired results pass. See `sensitivity_verification.md`. |
| Never sum overlapping 12-month-ending counts | Done | Snapshot selection and AVG used across windows. Sums of observed counts are across counties for a selected annual measure, or across non-overlapping calendar years when explicitly selected in the original dashboard; neither constructs annual deaths from monthly windows. |
| Never zero-fill suppression | Done | Missing measures and coverage flags retained; zero preservation tested. |
| Distinguish reported and derived/imputed values | Done | December classified as reported; smoothing classified as derived means, not annual death estimates; no analyst imputation. CDC dispensing rates are explicitly identified as source estimates. |
| Validate integrated county-year data | Done | Structural checks pass. Historical pandas metrics reproduce exactly; comma normalization explains all three current differences. Row-level recovery and regression tests are recorded in `pandas_reconciliation.md`. Exact bytes of the newly re-uploaded oversized overdose CSV remain unverified. |
| Interactive dashboard | Done with stated evidence limits | User-supplied overview/county captures and refreshed files for all six sensitivity plots show the expected visualizations. The latest original relationship screenshot shows numeric axes/points and is embedded. No independent browser test, hidden filter state or full rendered point count is claimed. |
| Pipeline architecture diagram | Done | Mermaid architecture in `architecture.md`. No exported image required or fabricated. |
| Automated data-quality checks and documentation | Done | CI source/hash checks, Spark execution, persisted local tables, strict-window checks, statistical reference tests, and quality documentation. CI does not verify Unity Catalog/Delta behavior or browser rendering. |

## Dashboard requirements

| View/control | Status | Evidence/qualification |
|---|---|---|
| Dispensing trends | Done | Original page, unweighted county rate means; not national rates. |
| Overdose trends | Done | Reported December subtotals plus coverage; not population-adjusted rates. |
| Geographic differences | Done | State comparisons and county detail/filter views; no county choropleth or spatial model is claimed. |
| County and state comparisons | Done | Original state charts and county details; limited by suppression and county population. |
| Dispensing–overdose relationships | Done with preview limit | The latest original scatter image shows numeric axes/points and is embedded beside a separately scoped fixed-cohort table; the image does not prove all cases were rendered. Research separately provides Pearson/Spearman by year/cohort/method. |
| Missing-data patterns | Done | Original missingness charts; sensitivity coverage and missingness comparisons. |
| Year, state, county filters | Done | Original filters explicitly confirmed by user. Sensitivity filters were added and the user reported reviewing that page; no individual automated filter assertions. |
| Annualization sensitivity | Done | SQL and five Delta outputs are verified; refreshed original captures show all six plots with numeric axes and distinct method series. |

## Research questions and safeguards

| Requirement | Status | Evidence/qualification |
|---|---|---|
| Association between dispensing and overdose | Done | 60 year/cohort/method summaries with Pearson and tie-adjusted Spearman; independently reproduced. Unadjusted descriptive associations only. |
| Changes from 2020–2024 | Done | Available/shared/fixed cohort means and changes; fixed-cohort endpoint direction differs across time summaries. |
| Geographic variation | Partial | 255 state-year descriptive/coverage summaries and county dashboard details. No formal county spatial analysis or population-adjusted risk analysis. Existing scope is descriptive. |
| Avoid causal claims about legally dispensed opioids | Done | Report/dashboard limitations distinguish dispensing from all-drug mortality and legal/illegal channels. |
| Dashboard first | Done | Dashboard created/reviewed before research expansion. |
| No unexplained extra datasets | Done | Only the two supplied CDC snapshots used. No population or boundary dataset added. |
| Document limitations/transforms | Done | Source inspection, methods, sensitivity, quality, findings, report draft, manifest, and runbook. Original-source provenance remains incomplete. |
| GitHub version control and incremental tests | Done | Repository commits and passing workflows; no credentials stored in project files. |
| No fabricated outputs/screenshots | Done | Full query exports and independently checked numerical findings; no screenshots claimed. |

## Historical validation targets

| Metric | Current | Prior target | Status |
|---|---:|---:|---|
| Raw dispensing | 18,864 | 18,864 | Match |
| Raw overdose | 226,368 | 226,368 | Match |
| Matching county FIPS | 3,142 | 3,142 | Match |
| Common county-years | 15,710 | 15,710 | Match |
| Complete observations | 8,203 | 8,180 | Explained: +23 reported values recovered |
| Complete-case counties | 2,388 | 2,385 | Explained: +3 complete-case counties |
| Missing dispensing | 297 | 297 | Match |
| Missing overdose | 7,275 | 7,298 | Explained: −23 numeric parse failures |

All historical targets are now reproduced using the original parsing behavior. The original `pd.to_numeric(errors="coerce")` coerced comma-formatted counts to missing. Removing commas alone recovers 23 reported values and yields all current metrics. This is a demonstrated parsing correction, not an assumed tolerance or a source-revision explanation. See the complete row-level reconciliation.

## Final deliverables and submission gaps

| Deliverable | Status | Remaining action |
|---|---|---|
| Working Databricks primary pipeline | Done | Primary outputs verified; capture managed runtime/job details for stronger handoff evidence. |
| Working interactive dashboard | Partial | Overview and county-detail screenshots are usable; relationship/sensitivity plot rendering remains open. Draft publication is separate.
| Reproducible code | Partial | Frozen snapshots, checksums, CI, exact queries/results and runbook available. Exact export/download and snapshot release history and managed runtime metadata remain missing. CI dependency is pinned but not a full lockfile. |
| Data-quality documentation | Done | Structural checks, coverage, suppression, aliases, geography, target differences documented. Historical discrepancies are resolved as a reproduced comma-parsing defect; original release provenance remains open. |
| Pipeline diagram | Done | Mermaid source updated for current architecture. |
| Final capstone report | Done with disclosed limitations | Formatted DOCX prepared using the supplied university structure, author/course/date, verified findings and references. Snapshot provenance remains incomplete. |
| Presentation and script | Partial | Revised 16-slide deck and matching script prepared with pipeline diagram, county-year arithmetic, four-method comparison and timed dashboard walkthrough. Overview/county and refreshed sensitivity captures are incorporated; the original relationship file is now embedded. The recording remains open. |
| Recorded presentation | Open | A 14:25 plan includes a 3:30 live demo. No MP4 or shareable video has been produced; actual duration and access must be checked. |

## Current presentation and submission closeout

The formatted report, revised presentation and timed script have been prepared after the initial audit. Presentation preparation does not establish that a video or screenshot exists. See `submission_checklist.md` for the final status and `presentation_demo.md` for exact page names, filters, timings and source-based example values.

1. Completed: incorporate supplied overview, county-example and refreshed sensitivity screenshots; retain their provenance. Document the relationship preview limit.
2. Rehearse and record both dashboard pages and real filter interactions, keeping the complete presentation within 10–15 minutes.
3. Provide an MP4 or accessible video link and check instructor access to the full submission.
4. Keep the methodological distinction explicit: December is a reported year-end benchmark; rolling/quarterly comparisons were implemented; strict smoothing does not impute suppressed values. The professor's acceptance of this response has not been established.

## Source documentation update

The user supplied both CDC source pages, verified November 13, 2026. Publication titles, dispensing units/source-estimation basis, prescriber-versus-resident geography, mortality windows, suppression rules, and mortality dataset ID are now documented in `source_citations.md`. Source landing-page identification is complete. Exact original export/download and uploaded-release provenance remain open. These links identify source definitions; the separately supplied pandas HTML and controlled rerun explain the historical 23-observation discrepancy.
