# Final submission checklist

Updated November 15, 2026 against the supplied assignment and professor feedback.

## Prepared

- [x] Report with sources, processing, verified findings, limitations and references, using the supplied university report structure.
- [x] Sixteen-slide presentation preserving the supplied artwork and arrangement, with updated findings and an editable data → PySpark → Delta → dashboard diagram.
- [x] Explicit explanation: 3,142 county FIPS × five years = 15,710 common-panel rows; 8,203 complete observations across 2,388 counties.
- [x] Four temporal definitions compared prominently; December identified as a reported year-end benchmark, not a universally preferred summary.
- [x] Strict smoothing distinguished from imputation, including evidence that wider strict windows reduce coverage. No imputed values are claimed.
- [x] Legal/illegal supply, all-drug counts versus dispensing rates, and prescriber versus resident geography explained without causal claims.
- [x] Script aligned with slide notes and a target duration of 14:25, including a 3:30 dashboard demonstration.
- [x] Actual dashboard API readback confirms both page definitions; genuine screenshots are not substituted with a mockup.
- [x] Code, frozen source ZIPs, manifests, analyses, tests, dashboard definition and documentation organized for a local submission package.
- [x] Future population-adjusted comparisons and justified crime/economic indicators identified without expanding the current analysis.

## Still required before submission

- [x] Receive and insert genuine overview and county-example screenshots into the report appendix and presentation.
- [x] Review refreshed original captures showing numeric axes and separate method series on all six sensitivity plots; incorporate them in the report, presentation and supporting materials.
- [x] Review and embed the original relationship image from the latest ZIP in the report and presentation. It shows numeric axes and points; the screenshot does not establish the filter state, fixed-cohort membership or total rendered count.
- [ ] Rehearse the actual browser walkthrough and confirm current rendering and filter behavior.
- [ ] Record the presentation, including both dashboard pages, your narration and filter interactions.
- [ ] Confirm the complete video is 10–15 minutes; target script timings are not a measured recording.
- [ ] Export MP4 or provide an accessible video link and test playback/access.
- [ ] Verify instructor access to the final files and any repository, dataset or video links used.
- [ ] If the professor requires actual imputation rather than a documented comparison and decision to preserve suppression, resolve that expectation. No imputation model has been implemented or accepted by the professor in the evidence available here.

Original source export/download dates and release history remain incomplete and disclosed. This does not create an additional explicit assignment deliverable. Managed runtime metadata could strengthen reproducibility, but no new analysis, population dataset or predictive model is claimed.
