# Capstone final submission materials

Lawrence Owoeye — DS-670 Capstone Project — Saint Peter's University

## Deliverables

- Deliverables/Capstone_Report_Final_v2.docx: formatted report, including refreshed dashboard evidence in the appendix.
- Deliverables/Capstone_Presentation_Final_v3.pptx: 16-slide presentation preserving the supplied university design, with actual county, sensitivity and relationship captures, editable results and an editable pipeline diagram.
- Deliverables/Capstone_Presentation_Final_v3.pdf: static preview of the presentation; use PowerPoint for speaker notes.
- Deliverables/Presentation_Script_Final_v3.docx: aligned narration and directions, targeting 14:25 including a 3:30 live dashboard demonstration. Rehearse to confirm an actual duration of 10–15 minutes.

## Supporting evidence

Supporting contains the diagram, architecture source, demonstration guide, checklist, screenshot review and dashboard definition readback. Screenshots contains the selected original files and a SHA-256/provenance manifest. Original_Capture_Archives contains the supplied Overview, County Example and refreshed Sensitivity Comparison archives. Superseded flat-plot archives are not included as final evidence.

All six sensitivity plots now show numeric axes and distinct method series in the refreshed original images. The sensitivity detail table preserves null observations. The latest archive includes the original relationship image, now embedded unchanged in report Figure 14 and presentation slide 11. This file shows numeric axes and points without the earlier visible Render more data control. Its filter state and full rendered point count are not inferred from the image. The screenshot is explicitly distinguished from the adjacent fixed-cohort correlation table.

## Project reproduction

Project contains the version-controlled source code, frozen CDC dataset ZIPs and checksums, notebooks, SQL, full research exports, tests, dashboard definition and documentation. Start with Project/README.md and Project/docs/reproducibility.md. The local source snapshot is commit 3bb0fef84e11bacf90812538d8deb95085237cf7. No remote GitHub push or hosted-file upload is implied by this local package.

The numeric-input repair preserves cohort rules and suppression. Twelve checks passed in the preceding code revision; the current change adds screenshot evidence and documentation. A bounded live Databricks query separately confirms revised fixed-cohort measures are numeric and match existing exports. These checks do not establish independent browser acceptance or the eventual recording duration.

Dashboard draft: https://dbc-dc957048-d7f2.cloud.databricks.com/sql/dashboardsv3/01f1df0509d010f987459df183dcdd91?o=7474646615740609
Repository: https://github.com/dheritageprojects/DS670Capstone

## Complete the submission

Rehearse the actual browser walkthrough, record the complete 10–15 minute presentation including both dashboard pages and filter interactions, and submit the MP4 or an accessible video link alongside these materials. Verify playback, audio, readable charts and instructor access. No recording is included in this package. Public dashboard publication is not required to make a complete recorded demonstration.

Dispensing is a source-estimated rate; mortality is an all-drug reported count, not population-adjusted risk or deaths attributable solely to legal prescriptions. December remains a reported year-end benchmark. Strict quarterly/monthly/rolling snapshot means do not impute suppressed counts and are not interchangeable annual death totals. Never sum overlapping windows. Original source export/download history remains incomplete and disclosed.

SHA256SUMS.txt identifies the exact packaged bytes. The selected image files and embedded screenshots retain the supplied bytes; no results or dashboard screenshots were fabricated.

## Classroom speaking-script revision

The matching DOCX script and all 16 PowerPoint speaker notes use first-person narration and explain the project for an audience without prior knowledge. The 14:25 rehearsal schedule includes a 3:30 browser demonstration. A readable script PDF is also included. Rehearse the complete recording to verify actual duration. The report, scientific results, visible slides, chart workbook, and source snapshot are unchanged.
